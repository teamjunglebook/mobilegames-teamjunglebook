﻿using UnityEngine;
using System.Collections;

public class ConstantGroundGenerator : MonoBehaviour {

	private CoinGenerator theCoinGenerator;

	//public GameObject[] thePlatforms;

	public Transform generationPoint;

	public float randomCoinThreshold;

	public float randomSpikeThreshold;
	public ObjectPooler theSpikePool;
	public ObjectPooler theConstantPlatformPool;

	public float platformGapThreshold;

	public float powerupHeight;
	public ObjectPooler powerupPool;
	public float powerupThreshold;

	// Use this for initialization
	void Start () {
		theCoinGenerator = FindObjectOfType<CoinGenerator> ();
	}

	// Update is called once per frame
	void Update () {
		if (transform.position.x < generationPoint.position.x) {

			float gap = 0;
			if (Random.Range (0f, 100f) < platformGapThreshold) {
				gap = Random.Range (1f, 5f);
			}
			// Generating Constant Ground
			transform.position = new Vector3 (transform.position.x + 5 + gap, transform.position.y, transform.position.z);
			GameObject constantPlatform = theConstantPlatformPool.GetPooledObject ();
			constantPlatform.transform.position = transform.position;
			constantPlatform.transform.rotation = transform.rotation;
			constantPlatform.SetActive (true);

			// Generating Coins / Fruits
			if (Random.Range (0f, 100f) < randomCoinThreshold) {

				float randomHeight = Random.Range (1f, 6f);
				/* if (randomHeight == FindObjectOfType<PlatformGenerator>().GetHeightChange()) {
					randomHeight += 2f;
				} */
				theCoinGenerator.SpawnCoins (Random.Range(1,6), new Vector3 (transform.position.x, transform.position.y + randomHeight, transform.position.z));
			}

			// Generating Spikes / Enemies
			if (Random.Range (0f, 100f) < randomSpikeThreshold) {
				GameObject newSpike = theSpikePool.GetPooledObject ();

				float spikeXPosition = Random.Range (5 / 2f + 1f, 5 / 2f - 1f);

				newSpike.transform.position = transform.position + new Vector3 (spikeXPosition, 0.5f, 0f);;
				newSpike.transform.rotation = transform.rotation;
				newSpike.SetActive (true);
			}

			// Generating Powerups
			if (Random.Range (0f, 100f) < powerupThreshold) {
				GameObject newPowerup = powerupPool.GetPooledObject ();
				newPowerup.transform.position = transform.position + new Vector3 (transform.position.x, Random.Range(1f, powerupHeight), 0f);
				newPowerup.SetActive (true);
			}

			/*
			// Coins / Fruits generated at height
			if (Random.Range (0f, 100f) < randomCoinThreshold) {
				theCoinGenerator.SpawnCoins (Random.Range(1,2), new Vector3 (transform.position.x, transform.position.y + 2f, transform.position.z));
			}
			*/

		}
	}
}
