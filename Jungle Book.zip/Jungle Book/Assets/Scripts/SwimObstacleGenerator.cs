﻿using UnityEngine;
using System.Collections;

public class SwimObstacleGenerator : MonoBehaviour {

	private int platformSelector;

	private float minHeight;
	private float maxHeight;
	private float heightChange;

	private CoinGenerator theCoinGenerator;

	public Transform maxHeightPoint;
	public Transform minHeightPoint;

	public ObjectPooler[] theObjectPools;

	//public GameObject[] thePlatforms;

	public Transform generationPoint;

	public float maxHeightChange;

	public float randomCoinThreshold;

	public float randomSpikeThreshold;
	public float temp;
	public ObjectPooler theSpikePool;

	public float upPlatformThreshold;

	// Use this for initialization
	void Start () {
		minHeight = minHeightPoint.position.y;
		maxHeight = maxHeightPoint.position.y;

		theCoinGenerator = FindObjectOfType<CoinGenerator> ();
	}

	// Update is called once per frame
	void Update () {

		float lastPositionX;

		if (transform.position.x < generationPoint.position.x) {

			// Generating Upper platforms
			if (Random.Range(0f,100f) < upPlatformThreshold) {
				platformSelector = Random.Range (0, theObjectPools.Length);
				heightChange = transform.position.y + Random.Range (maxHeightChange, -maxHeightChange);

				Vector3 newPosition = new Vector3 (transform.position.x, heightChange, transform.position.z);

				if (heightChange > maxHeight) {
					heightChange = maxHeight;
				}

				if (heightChange < minHeight) {
					heightChange = minHeight;
				}

				switch(Random.Range(0, 3)) {

				// Generating Obstacles
				case 0:
					GameObject newPlatform = theObjectPools [platformSelector].GetPooledObject ();
					newPlatform.transform.position = newPosition;
					newPlatform.transform.rotation = transform.rotation;
					newPlatform.SetActive (true);
					break;

				// Generating Coins / Fruits
				case 1:
					theCoinGenerator.SpawnCoins (Random.Range (1, 4), newPosition);
					break;

				// Generating Spikes / Enemies
				case 2:
					GameObject newSpike = theSpikePool.GetPooledObject ();
					newSpike.transform.position = newPosition;
					newSpike.transform.rotation = transform.rotation;
					newSpike.SetActive (true);
					break;
				}

				lastPositionX = transform.position.x;
				float newX = Random.Range (-1f, 20f);
				float newY = 0;

				if (lastPositionX <= newX) {
					newX = 0;
				}
				// New Platform position
				transform.position = new Vector3 (transform.position.x + newX, transform.position.y + newY, transform.position.z);

				/*
				// Coins / Fruits generated at height
				if (Random.Range (0f, 100f) < randomCoinThreshold) {
					theCoinGenerator.SpawnCoins (Random.Range(1,2), new Vector3 (transform.position.x, transform.position.y + 2f, transform.position.z));
				}
				*/
			}

		}
	}

	public float GetHeightChange() {
		return heightChange;
	}
}
