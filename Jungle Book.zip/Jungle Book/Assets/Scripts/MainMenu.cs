﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour {

	public string playGameLevel;
	public string level2;

	public void PlayGame() {
		Application.LoadLevel (playGameLevel);
	}

	public void PlayGame2() {
		Application.LoadLevel (level2);
	}

	public void ExitGame() {
		Application.Quit ();
	}
}
