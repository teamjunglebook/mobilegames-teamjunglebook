﻿using UnityEngine;
using System.Collections;

public class PlayerSwimController : MonoBehaviour {

	private Rigidbody2D myRigidbody;
	//private Collider2D myCollider;
	private Animator myAnimator;

	private float speedMilestoneCount;

	private float moveSpeedStore;
	private float speedMilestoneCountStore;
	private float speedupMilestoneStore;

	public float moveSpeed;
	public float speedMultiplier;
	public float jumpForce;
	public float speedupMilestone;

	public float jumpTime;

	public SwimGameManager theGameManager;

	public AudioSource deathSound1;
	public AudioSource backgroundSound;

	// Use this for initialization
	void Start () {
		myRigidbody = GetComponent<Rigidbody2D> ();
		myAnimator = GetComponent<Animator> ();

		speedMilestoneCount = speedupMilestone;

		moveSpeedStore = moveSpeed;
		speedMilestoneCountStore = speedMilestoneCount;
		speedupMilestoneStore = speedupMilestone;
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.x > speedMilestoneCount) {
			speedMilestoneCount += speedupMilestone;
			speedupMilestone = speedupMilestone * speedMultiplier;
			moveSpeed = moveSpeed * speedMultiplier;
		}

		myRigidbody.velocity = new Vector2 (moveSpeed, myRigidbody.velocity.y);

		JumpControl ();
	}

	void OnCollisionEnter2D (Collision2D other) {
		if (other.gameObject.tag == "killbox") {
			theGameManager.RestartGame ();
			moveSpeed = moveSpeedStore;
			speedMilestoneCount = speedMilestoneCountStore;
			speedupMilestone = speedupMilestoneStore;

			deathSound1.Play ();
			//deathSound2.Play ();
			backgroundSound.Stop ();
		}
	}

	public void JumpControl () {
		if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)) {
			myRigidbody.velocity = new Vector2 (myRigidbody.velocity.x, jumpForce);
		}

		myAnimator.SetFloat ("Speed", myRigidbody.velocity.x);
	}
}
