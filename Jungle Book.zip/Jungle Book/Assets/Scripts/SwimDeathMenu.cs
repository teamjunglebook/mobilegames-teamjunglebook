﻿using UnityEngine;
using System.Collections;

public class SwimDeathMenu : MonoBehaviour {

	public string mainMenuLevel;

	public void RestartGame () {
		FindObjectOfType<SwimGameManager> ().ResetGame();
	}

	public void QuitToMainMenu() {
		Application.LoadLevel (mainMenuLevel);
	}
}
