﻿using UnityEngine;
using System.Collections;

public class PowerupManager : MonoBehaviour {

	private bool doublePoints;
	private bool safeMode;
	private bool extraEnergy;
	private bool powerupActive;

	private float powerupLengthCounter;

	private ScoreManager theScoreManager;
	private ConstantGroundGenerator thePlatformGenerator;
	private EnergyManager theEnergyManager;
	private GameManager theGameManager;

	private float normalPointsPerSecond;
	private float spikeRate;

	private PlatformDestroyer[] spikeList;

	// Use this for initialization
	void Start () {
		theScoreManager = FindObjectOfType<ScoreManager> ();
		thePlatformGenerator = FindObjectOfType<ConstantGroundGenerator> ();
		theEnergyManager = FindObjectOfType<EnergyManager> ();
		theGameManager = FindObjectOfType<GameManager> ();
	}
	
	// Update is called once per frame
	void Update () {
		if (powerupActive) {
			powerupLengthCounter -= Time.deltaTime;

			if (theGameManager.powerupReset) {
				powerupLengthCounter = 0;
				theGameManager.powerupReset = false;
			}

			if (doublePoints) {
				theScoreManager.pointsPerSecond = normalPointsPerSecond * 2;
			}

			if (safeMode) {
				thePlatformGenerator.randomSpikeThreshold = 0f;
			}

			if (extraEnergy) {
				theEnergyManager.AddEnergy (20);
				extraEnergy = false;
			}

			if (powerupLengthCounter <= 0) {
				theScoreManager.pointsPerSecond = normalPointsPerSecond;
				thePlatformGenerator.randomSpikeThreshold = spikeRate;

				powerupActive = false;
			}
		}
	}

	public void ActivatePowerup (bool points, bool safe, bool extra, float time) {
		doublePoints = points;
		safeMode = safe;
		extraEnergy = extra;
		powerupLengthCounter = time;

		normalPointsPerSecond = theScoreManager.pointsPerSecond;
		spikeRate = thePlatformGenerator.randomSpikeThreshold;

		if (safeMode) {
			spikeList = FindObjectsOfType<PlatformDestroyer> ();
			for (int i = 0; i < spikeList.Length; i++) {
				if (spikeList[i].gameObject.name.Contains("KingLouie")) {
					spikeList [i].gameObject.SetActive (false);
				}
			}
		}

		powerupActive = true;

	}
}
